-- Execute esse SQL no Supabase
-- Acesse: SQL Editor no painel do Supabase e cole isso

create table consultoria_leads (
  id uuid default gen_random_uuid() primary key,
  created_at timestamp with time zone default now(),

  -- Bloco 1: Identificação
  nome text not null,
  whatsapp text not null,
  segmento text not null,
  papel text,

  -- Bloco 2: Nível técnico
  nivel_ia text,
  ferramentas text[],         -- array de strings
  tentativas_ia text,

  -- Bloco 3: Expectativas
  gatilho text,
  resultado_esperado text,
  areas_interesse text[],     -- array de strings
  prioridade text,

  -- Bloco 4: Comprometimento
  horas_semana text,
  equipe text,
  obstaculos text,
  porque_agora text
);

-- Habilita RLS (Row Level Security)
alter table consultoria_leads enable row level security;

-- Permite INSERT público (sem login) — necessário pro forms funcionar
create policy "Allow public insert"
  on consultoria_leads
  for insert
  to anon
  with check (true);

-- Só você (autenticado) pode ver os dados
create policy "Allow authenticated read"
  on consultoria_leads
  for select
  to authenticated
  using (true);
